<?php

 function emptyInputSignup($firstname, $lastname, $username, $email, $phone, $sex, $password_1, $password_2) {
    $result;
    if (empty($firstname) || empty($lastname) || empty($username) || empty($email) || empty($phone) || empty($sex) || empty($password_1) || empty($password_2)) {
        $result = true;
    } else {
        $result = false;
    }
        return $result;
 }

/* function invalidEmail($email) {
    $result;
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $result = true;
    } else {
        $result = false;
    }
        return $result;
 }*/

  function pwdMatch($password_1, $password_2) {
    $result;
    if ($password_1 !== $password_2) {
        $result = true;
    } else {
        $result = false;
    }
        return $result;
 }

 function uidExist($conn, $username, $email) {
    $sql = "SELECT * FROM users WHERE username = ? OR email = ?;";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: login.php?error=stmtfailed");
        exit();
    }

    mysqli_stmt_bind_param($stmt, "ss", $username, $email);
    mysqli_stmt_execute($stmt);

    $resultData = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($resultData)) {
        return $row;
    } else {
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
 }

  function createUser($conn, $firstname, $lastname , $username , $email, $phone, $sex, $password_1) {
    $sql = "INSERT INTO users (firstname, lastname, username, email, phone, sex, password) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: login.php?error=stmtfailed");
        exit();
    }

    $hashedPwd = password_hash($password_1, PASSWORD_DEFAULT);

    mysqli_stmt_bind_param($stmt, "sssssss", $firstname, $lastname , $username , $email, $phone, $sex, $hashedPwd);
    mysqli_stmt_execute($stmt);

    mysqli_stmt_close($stmt);

    header("location: login.php?error=none");
        exit();

 }

  function emptyInputLogin($username, $password) {
    $result;
    if (empty($username) || empty($password)) {
        $result = true;
    } else {
        $result = false;
    }
        return $result;
 }


 function loginUser($conn, $username, $password){
     $uidExist = uidExist($conn, $username, $email);

     if ($uidExist === false) {
         header("location: login.php?error=wronglogin");
        exit();
     }

     $pwdhashed = $uidExist["password"];
     $checkpwd = password_verify($password, $pwdhashed);

     if ($checkpwd === false) {
         header("location: login.php?error=wronglogin");
        exit();
     } elseif ($checkpwd === true) {
         session_start();
         $_SESSION['id'] = $uidExist["id"];
         $_SESSION['username'] = $uidExist["username"];
         header("location: index.php");
        exit();
     }
 }

