<?php

$serverName = "localhost";
$userAdmin = "root";
$pass = "";
$dbName = "solorex";

$conn = mysqli_connect($serverName, $userAdmin, $pass, $dbName);

 if (!$conn) {
     die("Connection failed: " . mysqli_connect_error());
  } 


?>
